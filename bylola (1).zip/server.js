import express from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const HOST = '0.0.0.0';

app.use(express.json());

// In-memory active session tokens: token -> { email, expiresAt }
const activeSessions = new Map();

// Helper to hash password
function hashPassword(pwd) {
  return crypto.createHash('sha256').update(pwd).digest('hex');
}

// Google Workspace Scopes
const SCOPES = [
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/calendar.events'
];

// Data file paths
const DATA_DIR = path.join(__dirname, 'data');
const SCHEDULE_FILE = path.join(DATA_DIR, 'schedule.json');
const ADMIN_FILE = path.join(DATA_DIR, 'admin.json');
const BOOKINGS_FILE = path.join(DATA_DIR, 'bookings.json');
const GOOGLE_INTEGRATION_FILE = path.join(DATA_DIR, 'google-integration.json');
const SERVICES_FILE = path.join(DATA_DIR, 'services.json');
const FIREBASE_CONFIG_FILE = path.join(__dirname, 'firebase-applet-config.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Read JSON helper
function readJson(filePath, defaultValue) {
  try {
    if (!fs.existsSync(filePath)) {
      fs.writeFileSync(filePath, JSON.stringify(defaultValue, null, 2));
      return defaultValue;
    }
    const raw = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err);
    return defaultValue;
  }
}

// Write JSON helper
function writeJson(filePath, data) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    return true;
  } catch (err) {
    console.error(`Error writing ${filePath}:`, err);
    return false;
  }
}

// Authorized Google Accounts verification
function getAuthorizedOwnerEmail() {
  const adminData = readJson(ADMIN_FILE, {});
  return (
    adminData.ownerEmail ||
    process.env.ADMIN_GOOGLE_EMAIL ||
    'hello@bylolaa.co.uk'
  ).trim().toLowerCase();
}

function isAuthorizedGoogleAccount(email) {
  if (!email || typeof email !== 'string') return false;
  const normalized = email.trim().toLowerCase();
  const adminData = readJson(ADMIN_FILE, {});
  const ownerEmail = getAuthorizedOwnerEmail();
  const allowed = [
    ownerEmail,
    adminData.ownerEmail,
    ...(Array.isArray(adminData.allowedEmails) ? adminData.allowedEmails : []),
    process.env.ADMIN_GOOGLE_EMAIL,
    'hello@bylolaa.co.uk'
  ]
    .filter(Boolean)
    .map(e => e.trim().toLowerCase());

  return allowed.includes(normalized);
}

// Auth middleware for admin endpoints
function requireAdmin(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ')
    ? authHeader.slice(7).trim()
    : req.headers['x-admin-token'];

  if (!token) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const session = activeSessions.get(token);
  if (!session || session.expiresAt < Date.now()) {
    if (session) activeSessions.delete(token);
    return res.status(401).json({ error: 'Session expired or invalid' });
  }

  req.admin = session;
  next();
}

// ---------------- GOOGLE WORKSPACE (GMAIL & CALENDAR) HELPERS ---------------- //

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function getGoogleIntegration() {
  return readJson(GOOGLE_INTEGRATION_FILE, {});
}

function makeEmailRaw({ to, from, subject, bodyHtml, bodyText }) {
  const boundary = `__bylola_msg_${Date.now()}__`;
  const utf8Subject = `=?utf-8?B?${Buffer.from(subject).toString('base64')}?=`;

  const lines = [
    `To: ${to}`,
    `From: bylola Studio <${from}>`,
    `Subject: ${utf8Subject}`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    '',
    `--${boundary}`,
    'Content-Type: text/plain; charset=utf-8',
    'Content-Transfer-Encoding: base64',
    '',
    Buffer.from(bodyText).toString('base64'),
    '',
    `--${boundary}`,
    'Content-Type: text/html; charset=utf-8',
    'Content-Transfer-Encoding: base64',
    '',
    Buffer.from(bodyHtml).toString('base64'),
    '',
    `--${boundary}--`
  ];

  return Buffer.from(lines.join('\r\n'))
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

async function sendGmailEmail({ to, from, subject, bodyHtml, bodyText, token }) {
  if (!token) throw new Error('Missing Google access token');

  const raw = makeEmailRaw({ to, from, subject, bodyHtml, bodyText });
  const response = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ raw })
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error?.message || `Gmail API error (${response.status})`);
  }
  return data;
}

function buildClientEmailHtml(booking, ownerEmail) {
  const refCode = (booking.id || '').toUpperCase();
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #f9f6f0; color: #1a1715; margin: 0; padding: 28px 14px; }
    .container { max-width: 580px; margin: 0 auto; background: #ffffff; border-radius: 6px; border: 1px solid #e7ded5; overflow: hidden; box-shadow: 0 4px 20px rgba(26,23,21,0.05); }
    .header { background: #1a1715; color: #fbf9f5; padding: 34px 28px 26px; text-align: center; }
    .header-logo { font-family: Georgia, serif; font-size: 28px; font-style: italic; letter-spacing: -0.5px; margin: 0 0 6px; color: #fbf9f5; }
    .header-tagline { font-size: 11px; letter-spacing: 0.12em; text-transform: uppercase; color: #cf9c86; margin: 0; }
    .content { padding: 32px 28px; }
    .greeting { font-size: 20px; font-weight: 500; margin: 0 0 14px; color: #1a1715; }
    .lead { font-size: 14.5px; line-height: 1.6; color: #524c47; margin: 0 0 22px; }
    .card { background: #fbf9f5; border: 1px solid #ede5da; border-radius: 4px; padding: 20px; margin-bottom: 22px; }
    .card-title { font-size: 11px; text-transform: uppercase; letter-spacing: 0.08em; color: #a8563a; font-weight: 600; margin: 0 0 12px; }
    .detail-table td { padding: 8px 4px; font-size: 13.5px; border-bottom: 1px dashed #e7dfd5; }
    .detail-table tr:last-child td { border-bottom: none; }
    .badge { display: inline-block; background: #27ae60; color: #ffffff; font-size: 11px; font-weight: 600; padding: 3px 8px; border-radius: 2px; }
    .notes-box { background: #ffffff; border-left: 3px solid #cf9c86; padding: 12px 14px; margin-top: 14px; font-size: 13px; color: #544c45; }
    .studio-guide { background: #f5f0ea; border-radius: 4px; padding: 16px 18px; font-size: 12.5px; color: #524c47; line-height: 1.6; margin-bottom: 22px; }
    .footer { text-align: center; padding: 20px 28px 28px; font-size: 12px; color: #8e857c; border-top: 1px solid #f0eae1; }
    .footer a { color: #a8563a; text-decoration: none; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1 class="header-logo">bylola</h1>
      <p class="header-tagline">Hand &amp; Nail Studio &middot; Mayfair, London</p>
    </div>
    <div class="content">
      <h2 class="greeting">Dear ${escapeHtml(booking.name || 'Client')},</h2>
      <p class="lead">Thank you for booking with bylola. Your appointment is <strong>confirmed</strong> and has been placed into our studio schedule.</p>
      
      <div class="card">
        <div class="card-title">Appointment Summary &middot; Ref #${escapeHtml(refCode)}</div>
        <table class="detail-table" width="100%" cellpadding="0" cellspacing="0">
          <tr>
            <td style="color:#7a736c; width:35%;">Treatment</td>
            <td style="color:#1a1715; font-weight:600; text-align:right;">${escapeHtml(booking.service)}</td>
          </tr>
          <tr>
            <td style="color:#7a736c;">Date</td>
            <td style="color:#1a1715; font-weight:600; text-align:right;">${escapeHtml(booking.date)}</td>
          </tr>
          <tr>
            <td style="color:#7a736c;">Time</td>
            <td style="color:#a8563a; font-weight:700; text-align:right; font-size:15px;">${escapeHtml(booking.time)}</td>
          </tr>
          <tr>
            <td style="color:#7a736c;">Location</td>
            <td style="color:#1a1715; font-weight:500; text-align:right;">14 Berkeley Court, Mayfair, London W1J 8AQ</td>
          </tr>
          <tr>
            <td style="color:#7a736c;">Status</td>
            <td style="text-align:right;"><span class="badge">Confirmed</span></td>
          </tr>
        </table>
        ${booking.notes ? `<div class="notes-box"><strong>Client Notes:</strong> ${escapeHtml(booking.notes)}</div>` : ''}
      </div>

      <div class="studio-guide">
        <strong>Studio Arrival &amp; Preparation:</strong><br>
        &bull; Please arrive 5 minutes prior to your allocated time.<br>
        &bull; We perform 100% waterless dry cuticle preparation with medical autoclave-sterilized instruments.<br>
        &bull; If you need to make changes or have questions, simply reply directly to this email at <a href="mailto:${escapeHtml(ownerEmail)}">${escapeHtml(ownerEmail)}</a>.
      </div>

      <p style="font-size:13px; color:#524c47; line-height:1.5; margin:0;">
        We look forward to seeing you.<br>
        <em>Warm regards,</em><br>
        <strong>Lola &amp; the bylola Studio Team</strong>
      </p>
    </div>
    <div class="footer">
      bylola Hand &amp; Nail Studio &middot; 14 Berkeley Court, Mayfair, London W1J 8AQ<br>
      Direct enquiries: <a href="mailto:${escapeHtml(ownerEmail)}">${escapeHtml(ownerEmail)}</a>
    </div>
  </div>
</body>
</html>`;
}

function buildAdminEmailHtml(booking, ownerEmail, appUrl) {
  const refCode = (booking.id || '').toUpperCase();
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #f5f0ea; color: #1a1715; margin: 0; padding: 24px 14px; }
    .container { max-width: 580px; margin: 0 auto; background: #ffffff; border-radius: 6px; border: 1px solid #e2d9cd; overflow: hidden; }
    .header { background: #1a1715; color: #fbf9f5; padding: 22px 24px; text-align: left; }
    .header h1 { font-family: Georgia, serif; font-size: 20px; margin: 0; font-weight: normal; font-style: italic; color:#ffffff; }
    .badge-alert { display: inline-block; background: #cf9c86; color: #1a1715; font-size: 11px; font-weight: 700; padding: 3px 8px; border-radius: 2px; text-transform: uppercase; margin-top: 6px; }
    .content { padding: 24px; }
    .lead { font-size: 14.5px; color: #332f2b; margin: 0 0 16px; line-height: 1.5; }
    .card { background: #fbf9f5; border: 1px solid #ebe4da; border-radius: 4px; padding: 18px; margin-bottom: 20px; }
    .card table td { padding: 7px 4px; font-size: 13.5px; border-bottom: 1px dashed #eae2d6; }
    .card table tr:last-child td { border-bottom: none; }
    .btn-action { display: inline-block; background: #1a1715; color: #ffffff !important; padding: 10px 22px; text-decoration: none; border-radius: 3px; font-size: 13px; font-weight: 600; }
    .footer { text-align: center; padding: 14px; font-size: 11.5px; color: #918880; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>bylola Studio &middot; New Client Reservation</h1>
      <span class="badge-alert">Google Calendar Updated</span>
    </div>
    <div class="content">
      <p class="lead">A client has just confirmed a new manicure appointment on your schedule:</p>
      
      <div class="card">
        <table width="100%" cellpadding="0" cellspacing="0">
          <tr>
            <td style="color:#7a736c; width:35%;">Client Name:</td>
            <td style="color:#1a1715; font-weight:700;">${escapeHtml(booking.name)}</td>
          </tr>
          <tr>
            <td style="color:#7a736c;">Contact Email:</td>
            <td><a href="mailto:${escapeHtml(booking.contact)}" style="color:#a8563a; text-decoration:underline;">${escapeHtml(booking.contact)}</a></td>
          </tr>
          ${booking.phone ? `<tr><td style="color:#7a736c;">Phone:</td><td style="color:#1a1715; font-weight:600;">${escapeHtml(booking.phone)}</td></tr>` : ''}
          <tr>
            <td style="color:#7a736c;">Treatment:</td>
            <td style="color:#1a1715; font-weight:600;">${escapeHtml(booking.service)}</td>
          </tr>
          <tr>
            <td style="color:#7a736c;">Date:</td>
            <td style="color:#1a1715; font-weight:600;">${escapeHtml(booking.date)}</td>
          </tr>
          <tr>
            <td style="color:#7a736c;">Time:</td>
            <td style="color:#a8563a; font-weight:700; font-size:15px;">${escapeHtml(booking.time)}</td>
          </tr>
          <tr>
            <td style="color:#7a736c;">Booking ID:</td>
            <td style="font-family:monospace; color:#544c45;">#${escapeHtml(refCode)}</td>
          </tr>
          <tr>
            <td style="color:#7a736c;">Google Calendar:</td>
            <td style="color:#27ae60; font-weight:600;">&#10003; Added to your primary calendar</td>
          </tr>
          ${booking.notes ? `
          <tr>
            <td colspan="2" style="padding-top:10px;">
              <div style="background:#ffffff; border-left:3px solid #cf9c86; padding:10px; font-size:12.5px;">
                <strong>Client Notes:</strong> ${escapeHtml(booking.notes)}
              </div>
            </td>
          </tr>` : ''}
        </table>
      </div>

      <div style="text-align:center; margin-top:20px;">
        <a href="${appUrl}/admin" class="btn-action">Open Studio Admin Portal &rarr;</a>
      </div>
    </div>
    <div class="footer">
      bylola Management System &middot; Automated Gmail &amp; Google Calendar Integration
    </div>
  </div>
</body>
</html>`;
}

async function createGoogleCalendarEvent(booking, token) {
  if (!token) throw new Error('Missing Google access token');

  let duration = 75;
  if (typeof booking.service === 'string') {
    const s = booking.service.toLowerCase();
    // Try to extract duration directly from dynamic service list
    const services = readJson(SERVICES_FILE, []);
    const matched = services.find(srv => srv.name && s.includes(srv.name.toLowerCase()));
    if (matched && Number(matched.durationMinutes) > 0) {
      duration = Number(matched.durationMinutes);
    } else {
      const matchMin = s.match(/(\d+)\s*min/);
      if (matchMin && matchMin[1]) {
        duration = parseInt(matchMin[1], 10);
      } else if (s.includes('60 min') || s.includes('60min') || s.includes('signature')) {
        duration = 60;
      } else if (s.includes('90 min') || s.includes('90min') || s.includes('full design') || s.includes('art')) {
        duration = 90;
      } else if (s.includes('75 min') || s.includes('75min')) {
        duration = 75;
      }
    }
  }

  const [h, m] = (booking.time || '10:00').split(':').map(Number);
  const pad = n => String(n).padStart(2, '0');
  const startIso = `${booking.date}T${pad(h)}:${pad(m)}:00`;

  const totalStartMinutes = (isNaN(h) ? 10 : h) * 60 + (isNaN(m) ? 0 : m);
  const totalEndMinutes = totalStartMinutes + duration;
  const endH = Math.floor(totalEndMinutes / 60);
  const endM = totalEndMinutes % 60;
  const endIso = `${booking.date}T${pad(endH)}:${pad(endM)}:00`;

  const clientName = booking.name || 'Client';
  const cleanService = (booking.service || 'Builder Gel').split('(')[0].trim();

  const eventPayload = {
    summary: `bylola: ${cleanService} — ${clientName}`,
    description: [
      `Appointment: ${cleanService}`,
      `Client: ${clientName}`,
      `Email: ${booking.contact || 'None'}`,
      booking.phone ? `Phone: ${booking.phone}` : null,
      `Service: ${booking.service}`,
      `Booking Reference: #${booking.id}`,
      booking.notes ? `Client Notes: ${booking.notes}` : null,
      '',
      'Studio Location:',
      'bylola Hand & Nail Studio',
      '14 Berkeley Court, Mayfair, London W1J 8AQ'
    ].filter(Boolean).join('\n'),
    location: '14 Berkeley Court, Mayfair, London W1J 8AQ',
    start: {
      dateTime: startIso,
      timeZone: 'Europe/London'
    },
    end: {
      dateTime: endIso,
      timeZone: 'Europe/London'
    },
    reminders: {
      useDefault: false,
      overrides: [
        { method: 'email', minutes: 1440 },
        { method: 'popup', minutes: 60 }
      ]
    }
  };

  if (booking.contact && booking.contact.includes('@')) {
    eventPayload.attendees = [{ email: booking.contact.trim(), displayName: clientName }];
  }

  let response = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events?sendUpdates=all', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(eventPayload)
  });

  if (!response.ok) {
    delete eventPayload.attendees;
    response = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(eventPayload)
    });
  }

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error?.message || `Google Calendar API error (${response.status})`);
  }
  return data;
}

async function deleteGoogleCalendarEvent(eventId, token) {
  if (!eventId || !token) return;
  try {
    const res = await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events/${encodeURIComponent(eventId)}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return res.ok;
  } catch (err) {
    console.warn('[Google Calendar] Could not delete event:', err.message);
  }
}

// Background auto-sync function: automatically syncs any unsynced bookings to Google Calendar
async function autoSyncUnsyncedBookings() {
  const integration = readJson(GOOGLE_INTEGRATION_FILE, {});
  const token = integration.accessToken;
  if (!token) return;

  const bookings = readJson(BOOKINGS_FILE, []);
  let updatedAny = false;

  for (const b of bookings) {
    if (b.status !== 'cancelled' && !b.calendarSynced) {
      try {
        const calEvent = await createGoogleCalendarEvent(b, token);
        if (calEvent && calEvent.id) {
          b.calendarSynced = true;
          b.calendarEventId = calEvent.id;
          b.calendarEventUrl = calEvent.htmlLink;
          b.googleCalendarPending = false;
          updatedAny = true;
          console.log(`[Google Calendar Auto-Sync] ✓ Automatically placed booking #${b.id} (${b.name}) on Google Calendar`);
        }
      } catch (err) {
        console.warn(`[Google Calendar Auto-Sync] Failed for booking #${b.id}:`, err.message);
      }
    }
  }

  if (updatedAny) {
    writeJson(BOOKINGS_FILE, bookings);
  }
}

async function processBookingGoogleIntegrations(booking, explicitToken = null) {
  const result = {
    calendarSynced: false,
    calendarEventId: null,
    calendarEventUrl: null,
    emailClientSent: false,
    emailAdminSent: false,
    errors: []
  };

  const integration = readJson(GOOGLE_INTEGRATION_FILE, {});
  const token = explicitToken || integration.accessToken;
  const ownerEmail = getAuthorizedOwnerEmail();
  const appUrl = process.env.APP_URL || `http://localhost:${PORT}`;

  if (!token) {
    console.warn('[Google Workspace] No access token available yet. Marking booking sync as pending.');
    booking.googleCalendarPending = true;
    booking.emailPending = true;
    return result;
  }

  // 1. Google Calendar event (Automated)
  try {
    const calEvent = await createGoogleCalendarEvent(booking, token);
    result.calendarSynced = true;
    result.calendarEventId = calEvent.id;
    result.calendarEventUrl = calEvent.htmlLink;
    booking.calendarEventId = calEvent.id;
    booking.calendarEventUrl = calEvent.htmlLink;
    booking.calendarSynced = true;
    booking.googleCalendarPending = false;
    console.log(`[Google Calendar] Successfully created automated event for ${booking.name}: ${calEvent.id}`);
  } catch (err) {
    console.error('[Google Calendar] Error creating event:', err.message);
    result.errors.push(`Calendar: ${err.message}`);
    booking.googleCalendarPending = true;
  }

  // 2. Client Confirmation Email
  if (booking.contact && booking.contact.includes('@')) {
    try {
      const clientHtml = buildClientEmailHtml(booking, ownerEmail);
      const clientText = `Hello ${booking.name},\n\nYour appointment for ${booking.service} at bylola Studio has been confirmed for ${booking.date} at ${booking.time}.\nLocation: 14 Berkeley Court, Mayfair, London W1J 8AQ\nReference: #${booking.id}\n\nWarm regards,\nLola & the bylola Studio team`;

      await sendGmailEmail({
        to: booking.contact.trim(),
        from: ownerEmail,
        subject: `Your Appointment is Confirmed — bylola Studio London (${booking.date})`,
        bodyHtml: clientHtml,
        bodyText: clientText,
        token
      });
      result.emailClientSent = true;
      booking.emailClientSent = true;
      console.log(`[Gmail] Sent client confirmation email to ${booking.contact}`);
    } catch (err) {
      console.error('[Gmail] Error sending client confirmation email:', err.message);
      result.errors.push(`Client Email: ${err.message}`);
      booking.emailClientPending = true;
    }
  }

  // 3. Admin Notification Email
  try {
    const adminHtml = buildAdminEmailHtml(booking, ownerEmail, appUrl);
    const adminText = `New booking received from ${booking.name} for ${booking.service} on ${booking.date} at ${booking.time}.\nClient Email: ${booking.contact}\nReference: #${booking.id}\nNotes: ${booking.notes || 'None'}\n\nView at ${appUrl}/admin`;

    await sendGmailEmail({
      to: ownerEmail,
      from: ownerEmail,
      subject: `🗓️ New Booking: ${booking.name} — ${(booking.service || 'Manicure').split('(')[0].trim()} (${booking.date} at ${booking.time})`,
      bodyHtml: adminHtml,
      bodyText: adminText,
      token
    });
    result.emailAdminSent = true;
    booking.emailAdminSent = true;
    console.log(`[Gmail] Sent admin notification email to ${ownerEmail}`);
  } catch (err) {
    console.error('[Gmail] Error sending admin notification email:', err.message);
    result.errors.push(`Admin Email: ${err.message}`);
    booking.emailAdminPending = true;
  }

  if (result.calendarSynced || result.emailClientSent || result.emailAdminSent) {
    integration.lastActivity = new Date().toISOString();
    writeJson(GOOGLE_INTEGRATION_FILE, integration);
  }

  return result;
}

// ---------------- API ENDPOINTS: AUTHENTICATION ---------------- //

// Public Google Auth Configuration
app.get('/api/admin/google-config', (req, res) => {
  const clientId = process.env.GOOGLE_CLIENT_ID || process.env.CLIENT_ID || '';
  const ownerEmail = getAuthorizedOwnerEmail();
  res.json({
    configured: !!clientId,
    clientId: clientId || null,
    ownerEmail,
    name: 'Lola'
  });
});

// OAuth Provider URL for Google Popup Flow
app.get('/api/auth/google/url', (req, res) => {
  const clientId = process.env.GOOGLE_CLIENT_ID || process.env.CLIENT_ID;
  const appUrl = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
  const redirectUri = `${appUrl}/auth/callback`;

  if (!clientId) {
    return res.json({
      configured: false,
      redirectUri,
      ownerEmail: getAuthorizedOwnerEmail(),
      message: 'Google Client ID not configured in environment. Verified Google Login is available.'
    });
  }

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'openid email profile',
    prompt: 'select_account',
    access_type: 'online'
  });

  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params}`;
  res.json({ configured: true, url: authUrl, redirectUri, ownerEmail: getAuthorizedOwnerEmail() });
});

// OAuth Callback Handler (Popup receiver)
app.get(['/auth/callback', '/auth/callback/'], async (req, res) => {
  const { code, error } = req.query;

  if (error) {
    return res.send(`
      <!DOCTYPE html>
      <html>
        <head><title>Google Authentication</title></head>
        <body style="font-family:sans-serif;padding:30px;background:#faf7f2;color:#2c2825;text-align:center;">
          <h2 style="color:#c0392b;">Authentication Error</h2>
          <p>${escape(error)}</p>
          <script>
            if (window.opener) {
              window.opener.postMessage({ type: 'OAUTH_AUTH_ERROR', error: ${JSON.stringify(error)} }, '*');
              setTimeout(() => window.close(), 1500);
            }
          </script>
        </body>
      </html>
    `);
  }

  if (!code) {
    return res.status(400).send('Missing authorization code');
  }

  try {
    const clientId = process.env.GOOGLE_CLIENT_ID || process.env.CLIENT_ID;
    const clientSecret = process.env.GOOGLE_CLIENT_SECRET || process.env.CLIENT_SECRET;
    const appUrl = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
    const redirectUri = `${appUrl}/auth/callback`;

    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uri: redirectUri,
        grant_type: 'authorization_code'
      })
    });
    const tokenData = await tokenRes.json();
    if (!tokenRes.ok || !tokenData.access_token) {
      throw new Error(tokenData.error_description || 'Failed to exchange Google OAuth code');
    }

    const userRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${tokenData.access_token}` }
    });
    const profile = await userRes.json();
    const userEmail = (profile.email || '').trim().toLowerCase();

    if (!isAuthorizedGoogleAccount(userEmail)) {
      return res.send(`
        <!DOCTYPE html>
        <html>
          <head><title>Access Denied - bylola Studio</title></head>
          <body style="font-family:sans-serif;padding:30px;background:#faf7f2;color:#2c2825;text-align:center;">
            <h2 style="color:#c0392b;margin-bottom:12px;">Access Denied (403)</h2>
            <p style="font-size:14px;color:#666;max-width:400px;margin:0 auto 20px;">
              The Google account <strong>${userEmail}</strong> is not authorized to access this studio portal. Only Lola's registered account has access.
            </p>
            <script>
              if (window.opener) {
                window.opener.postMessage({
                  type: 'OAUTH_AUTH_ERROR',
                  error: 'Access Denied: The Google account (' + ${JSON.stringify(userEmail)} + ') is not authorized. Access is strictly granted to Lola only.'
                }, '*');
                setTimeout(() => window.close(), 2500);
              }
            </script>
          </body>
        </html>
      `);
    }

    // Save fresh access token for automatic Google Calendar & Gmail synchronization
    writeJson(GOOGLE_INTEGRATION_FILE, {
      accessToken: tokenData.access_token,
      refreshToken: tokenData.refresh_token || undefined,
      email: userEmail,
      name: profile.name || 'Lola',
      expiresAt: Date.now() + (tokenData.expires_in || 3600) * 1000,
      savedAt: new Date().toISOString(),
      scopes: SCOPES
    });
    console.log('[Google Workspace] Stored OAuth token in callback for', userEmail);
    autoSyncUnsyncedBookings().catch(e => console.warn('[Auto-Sync]', e.message));

    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = Date.now() + 7 * 24 * 60 * 60 * 1000;
    activeSessions.set(token, {
      email: userEmail,
      name: profile.name || 'Lola',
      picture: profile.picture || null,
      provider: 'google',
      googleAccessToken: tokenData.access_token,
      expiresAt
    });

    return res.send(`
      <!DOCTYPE html>
      <html>
        <head><title>Authenticated</title></head>
        <body style="font-family:sans-serif;padding:30px;background:#faf7f2;color:#2c2825;text-align:center;">
          <h2 style="color:#27ae60;">Authentication Successful</h2>
          <p>Welcome back, ${escape(profile.name || 'Lola')}. Closing window...</p>
          <script>
            if (window.opener) {
              window.opener.postMessage({
                type: 'OAUTH_AUTH_SUCCESS',
                token: ${JSON.stringify(token)},
                user: {
                  name: ${JSON.stringify(profile.name || 'Lola')},
                  email: ${JSON.stringify(userEmail)},
                  picture: ${JSON.stringify(profile.picture || null)}
                }
              }, '*');
              setTimeout(() => window.close(), 600);
            } else {
              window.location.href = '/admin';
            }
          </script>
        </body>
      </html>
    `);
  } catch (err) {
    return res.send(`
      <!DOCTYPE html>
      <html>
        <body style="font-family:sans-serif;padding:30px;background:#faf7f2;color:#c0392b;text-align:center;">
          <h2>Authentication Error</h2>
          <p>${escape(err.message)}</p>
          <script>
            if (window.opener) {
              window.opener.postMessage({ type: 'OAUTH_AUTH_ERROR', error: ${JSON.stringify(err.message)} }, '*');
              setTimeout(() => window.close(), 2000);
            }
          </script>
        </body>
      </html>
    `);
  }
});

// Primary Google Login Endpoint (Google ID Token or Verified Google Sign-In)
app.post('/api/admin/google-login', async (req, res) => {
  const { credential, email, name, picture, googleAccessToken } = req.body || {};
  let userEmail = '';
  let userName = name || 'Lola';
  let userPicture = picture || null;

  // 1. If Google ID Token is provided (from Google Identity Services)
  if (credential) {
    try {
      const verifyRes = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential)}`);
      if (verifyRes.ok) {
        const tokenInfo = await verifyRes.json();
        userEmail = (tokenInfo.email || '').trim().toLowerCase();
        userName = tokenInfo.name || userName;
        userPicture = tokenInfo.picture || userPicture;
      }
    } catch (e) {
      console.warn('Google token verification failed:', e);
    }
  }

  // Fallback to provided email if no ID token verification occurred
  if (!userEmail && email) {
    userEmail = email.trim().toLowerCase();
  }

  if (!userEmail) {
    return res.status(400).json({ error: 'A valid Google account email is required for authentication' });
  }

  // STRICT ACCESS CHECK: Only Lola's authorized account is granted access!
  if (!isAuthorizedGoogleAccount(userEmail)) {
    return res.status(403).json({
      authorized: false,
      error: `Access Denied: The Google account (${userEmail}) is not authorized. Access is strictly granted to Lola's authorized studio account (${getAuthorizedOwnerEmail()}) only.`
    });
  }

  // If OAuth access token was obtained, save for Gmail & Google Calendar integrations
  if (googleAccessToken) {
    writeJson(GOOGLE_INTEGRATION_FILE, {
      accessToken: googleAccessToken,
      email: userEmail,
      name: userName,
      expiresAt: Date.now() + 3600 * 1000,
      savedAt: new Date().toISOString(),
      scopes: SCOPES
    });
    console.log('[Google Workspace] Stored Google OAuth access token for', userEmail);
    autoSyncUnsyncedBookings().catch(e => console.warn('[Auto-Sync]', e.message));
  }

  // Authorized: Create active session
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = Date.now() + 7 * 24 * 60 * 60 * 1000; // 7 days
  activeSessions.set(token, {
    email: userEmail,
    name: userName,
    picture: userPicture,
    provider: 'google',
    googleAccessToken: googleAccessToken || null,
    expiresAt
  });

  return res.json({
    token,
    name: userName,
    email: userEmail,
    picture: userPicture,
    provider: 'google',
    googleConnected: !!googleAccessToken,
    expiresAt
  });
});

// Disabled Legacy Password Login
app.post('/api/admin/login', (req, res) => {
  return res.status(403).json({
    error: 'Password login has been permanently disabled. The admin portal is restricted to authorized Google Login only.'
  });
});

// Admin Check Session
app.get('/api/admin/me', requireAdmin, (req, res) => {
  res.json({ authenticated: true, user: req.admin });
});

// Admin Logout
app.post('/api/admin/logout', requireAdmin, (req, res) => {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ')
    ? authHeader.slice(7).trim()
    : req.headers['x-admin-token'];
  if (token) activeSessions.delete(token);
  res.json({ message: 'Logged out' });
});

// Admin Access Settings (View & manage authorized Google accounts)
app.get('/api/admin/access-settings', requireAdmin, (req, res) => {
  const adminData = readJson(ADMIN_FILE, {});
  res.json({
    ownerEmail: getAuthorizedOwnerEmail(),
    allowedEmails: adminData.allowedEmails || [getAuthorizedOwnerEmail()],
    authMethod: 'google_only'
  });
});

app.post('/api/admin/access-settings', requireAdmin, (req, res) => {
  const { ownerEmail, allowedEmails } = req.body || {};
  const adminData = readJson(ADMIN_FILE, {});

  if (ownerEmail && ownerEmail.includes('@')) {
    adminData.ownerEmail = ownerEmail.trim().toLowerCase();
  }
  if (Array.isArray(allowedEmails)) {
    adminData.allowedEmails = allowedEmails.map(e => e.trim().toLowerCase()).filter(e => e.includes('@'));
  }
  adminData.updatedAt = new Date().toISOString();
  writeJson(ADMIN_FILE, adminData);

  res.json({
    message: 'Access settings updated',
    ownerEmail: adminData.ownerEmail,
    allowedEmails: adminData.allowedEmails
  });
});

// 5. Get Schedule (Public)
app.get('/api/schedule', (req, res) => {
  const schedule = readJson(SCHEDULE_FILE, {
    openDays: [1, 2, 3, 4, 5, 6],
    slots: [
      { id: "10-00", time: "10:00", label: "10:00 AM", period: "Morning", enabled: true },
      { id: "11-30", time: "11:30", label: "11:30 AM", period: "Midday", enabled: true },
      { id: "13-15", time: "13:15", label: "1:15 PM", period: "Afternoon", enabled: true },
      { id: "14-45", time: "14:45", label: "2:45 PM", period: "Afternoon", enabled: true },
      { id: "16-30", time: "16:30", label: "4:30 PM", period: "Late Afternoon", enabled: true },
      { id: "18-00", time: "18:00", label: "6:00 PM", period: "Sunset Session", enabled: true }
    ],
    blackoutDates: [],
    dateOverrides: {},
    noticeHours: 2
  });
  res.json(schedule);
});

// 6. Update Schedule (Admin only)
app.put('/api/schedule', requireAdmin, (req, res) => {
  const current = readJson(SCHEDULE_FILE, {});
  const updated = {
    ...current,
    ...req.body,
    updatedAt: new Date().toISOString()
  };

  if (!Array.isArray(updated.openDays)) {
    return res.status(400).json({ error: 'openDays must be an array of weekday numbers (0-6)' });
  }
  if (!Array.isArray(updated.slots)) {
    return res.status(400).json({ error: 'slots must be an array' });
  }

  writeJson(SCHEDULE_FILE, updated);
  res.json({ message: 'Schedule updated successfully', schedule: updated });
});

// Default initial services in case file doesn't exist
const DEFAULT_SERVICES = [
  {
    id: "builder-one-colour",
    name: "Builder Gel - One Colour",
    price: 35,
    priceDisplay: "£35",
    durationMinutes: 60,
    description: "Full builder gel manicure in colour of your choice.",
    category: "classic",
    image: "/assets/images/builder-one-colour.png",
    popular: false
  },
  {
    id: "builder-minimal-design",
    name: "Builder Gel - Minimal Design",
    price: 40,
    priceDisplay: "£40",
    durationMinutes: 75,
    description: "Builder gel manicure with minimal nail art, such as French tips, simple lines, dots or other subtle designs. One colour gel polish included.",
    category: "art",
    image: "/assets/images/builder-minimal-design.png",
    popular: true
  },
  {
    id: "builder-full-design",
    name: "Builder Gel - Full Design",
    price: 45,
    priceDisplay: "£45+",
    durationMinutes: 90,
    description: "Builder gel manicure with more detailed or intricate nail art. Final price may vary depending on the complexity of your chosen design.",
    category: "art",
    image: "/assets/images/builder-full-design.png",
    popular: false
  }
];

// 6b. Get Services (Public)
app.get('/api/services', (req, res) => {
  const services = readJson(SERVICES_FILE, DEFAULT_SERVICES);
  res.json(services);
});

// 6c. Update Services (Admin only)
app.put('/api/services', requireAdmin, (req, res) => {
  const body = req.body;
  if (!Array.isArray(body)) {
    return res.status(400).json({ error: 'Services payload must be an array of services' });
  }

  // Validate each service
  const current = readJson(SERVICES_FILE, DEFAULT_SERVICES);
  const updatedServices = body.map((item, idx) => {
    const existing = current.find(c => c.id === item.id) || current[idx] || {};
    const priceNum = Number(item.price);
    const durationNum = Number(item.durationMinutes);
    const priceDisplay = item.priceDisplay ? String(item.priceDisplay).trim() : `£${priceNum || 0}`;

    return {
      id: item.id || existing.id || `service-${Date.now()}-${idx}`,
      name: item.name ? String(item.name).trim() : existing.name || 'Treatment',
      price: !isNaN(priceNum) && priceNum >= 0 ? priceNum : (existing.price || 0),
      priceDisplay: priceDisplay,
      durationMinutes: !isNaN(durationNum) && durationNum > 0 ? durationNum : (existing.durationMinutes || 60),
      description: item.description ? String(item.description).trim() : (existing.description || ''),
      category: item.category || existing.category || 'classic',
      image: item.image || existing.image || '/assets/images/builder-one-colour.png',
      popular: typeof item.popular === 'boolean' ? item.popular : (existing.popular || false)
    };
  });

  writeJson(SERVICES_FILE, updatedServices);
  console.log(`[Services] Updated ${updatedServices.length} studio services with new prices/durations`);
  res.json({ message: 'Services updated successfully', services: updatedServices });
});

// 7. Get All Bookings (Admin only - Automatically ensures Google Calendar sync)
app.get('/api/bookings', requireAdmin, async (req, res) => {
  try {
    await autoSyncUnsyncedBookings();
  } catch (err) {
    console.warn('[Google Calendar Auto-Sync Error on fetch]', err.message);
  }
  const bookings = readJson(BOOKINGS_FILE, []);
  res.json(bookings);
});

// 8. Create Booking (Public booking modal)
app.post('/api/bookings', async (req, res) => {
  const { service, date, time, name, contact, phone, notes } = req.body || {};

  if (!service || !date || !time || !name || !contact) {
    return res.status(400).json({ error: 'Missing required booking fields (service, date, time, name, and email contact are required)' });
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const bookingDateCheck = new Date(date + 'T23:59:59');
  if (bookingDateCheck < today) {
    return res.status(400).json({ error: 'Cannot book an appointment for a past date.' });
  }

  const schedule = readJson(SCHEDULE_FILE, {});

  // Check if date is in blackoutDates
  if (schedule.blackoutDates && schedule.blackoutDates.includes(date)) {
    return res.status(400).json({ error: 'The studio is closed on this selected date.' });
  }

  // Check dateOverrides
  if (schedule.dateOverrides && schedule.dateOverrides[date]) {
    const override = schedule.dateOverrides[date];
    if (override.closed) {
      return res.status(400).json({ error: 'The studio is closed on this selected date.' });
    }
    if (Array.isArray(override.slots) && override.slots.length > 0) {
      if (!override.slots.includes(time)) {
        return res.status(400).json({ error: 'This time slot is not offered on the selected date.' });
      }
    }
  } else {
    // Check default weekday if no specific override exists
    const bookingDate = new Date(date + 'T12:00:00');
    const dayOfWeek = bookingDate.getDay();
    if (schedule.openDays && !schedule.openDays.includes(dayOfWeek)) {
      return res.status(400).json({ error: 'Appointments are not available on this day of the week.' });
    }
  }

  const bookings = readJson(BOOKINGS_FILE, []);

  // Check if slot on this date is already booked
  const conflict = bookings.find(b => b.date === date && b.time === time && b.status !== 'cancelled');
  if (conflict) {
    return res.status(409).json({ error: 'This time slot on the selected date is already booked. Please choose another time.' });
  }

  const newBooking = {
    id: 'bylola-' + Date.now().toString(36) + Math.random().toString(36).substr(2, 4),
    service: service.trim(),
    date,
    time,
    name: name.trim(),
    contact: contact.trim(),
    phone: (phone || '').trim(),
    notes: (notes || '').trim(),
    status: 'confirmed',
    createdAt: new Date().toISOString()
  };

  // Automatically execute Google Workspace integration:
  // 1. Sends email confirmation to client
  // 2. Sends notification email to admin
  // 3. Creates event on admin's Google Calendar
  const explicitToken = req.headers['x-google-token'] || (req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.slice(7) : null);
  const syncResult = await processBookingGoogleIntegrations(newBooking, explicitToken);

  bookings.unshift(newBooking);
  writeJson(BOOKINGS_FILE, bookings);

  res.status(201).json({
    message: 'Booking confirmed successfully',
    booking: newBooking,
    emailStatus: {
      clientSent: !!newBooking.emailClientSent,
      adminSent: !!newBooking.emailAdminSent
    },
    calendarStatus: {
      synced: !!newBooking.calendarSynced,
      eventId: newBooking.calendarEventId || null,
      eventUrl: newBooking.calendarEventUrl || null
    },
    syncResult
  });
});

// 8b. Manual or Retry Sync of a Booking to Google Calendar & Gmail (Admin only)
app.post('/api/bookings/:id/sync-google', requireAdmin, async (req, res) => {
  const { id } = req.params;
  const bookings = readJson(BOOKINGS_FILE, []);
  const booking = bookings.find(b => b.id === id);
  if (!booking) {
    return res.status(404).json({ error: 'Booking not found' });
  }

  const explicitToken = req.headers['x-google-token'] || req.body?.googleToken;
  const syncResult = await processBookingGoogleIntegrations(booking, explicitToken);
  booking.updatedAt = new Date().toISOString();
  writeJson(BOOKINGS_FILE, bookings);

  res.json({
    message: 'Google Workspace sync completed',
    booking,
    syncResult
  });
});

// 9. Update Booking Status (Admin only)
app.patch('/api/bookings/:id', requireAdmin, async (req, res) => {
  const { id } = req.params;
  const { status, notes, time, date } = req.body || {};
  const bookings = readJson(BOOKINGS_FILE, []);

  const booking = bookings.find(b => b.id === id);
  if (!booking) {
    return res.status(404).json({ error: 'Booking not found' });
  }

  const dateOrTimeChanged = (date && date !== booking.date) || (time && time !== booking.time);

  if (status) booking.status = status;
  if (notes !== undefined) booking.notes = notes;
  if (time) booking.time = time;
  if (date) booking.date = date;
  booking.updatedAt = new Date().toISOString();

  // If time/date changed and calendar event exists, update it on Google Calendar
  if (dateOrTimeChanged && booking.calendarEventId) {
    try {
      const explicitToken = req.headers['x-google-token'] || req.body?.googleToken;
      const integration = readJson(GOOGLE_INTEGRATION_FILE, {});
      const token = explicitToken || integration.accessToken;
      if (token) {
        let duration = 75;
        if (booking.service.includes('60 min')) duration = 60;
        else if (booking.service.includes('90 min')) duration = 90;

        const totalStartMinutes = (isNaN(h) ? 10 : h) * 60 + (isNaN(m) ? 0 : m);
        const totalEndMinutes = totalStartMinutes + duration;
        const endH = Math.floor(totalEndMinutes / 60);
        const endM = totalEndMinutes % 60;
        const endIso = `${booking.date}T${pad(endH)}:${pad(endM)}:00`;

        await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events/${encodeURIComponent(booking.calendarEventId)}`, {
          method: 'PATCH',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            start: { dateTime: startIso, timeZone: 'Europe/London' },
            end: { dateTime: endIso, timeZone: 'Europe/London' }
          })
        });
        console.log(`[Google Calendar] Updated event timing for ${booking.id}`);
      }
    } catch (err) {
      console.warn('Failed to update Google Calendar event timing:', err.message);
    }
  }

  // If status changed to cancelled, update event title on Google Calendar
  if (status === 'cancelled' && booking.calendarEventId) {
    try {
      const integration = readJson(GOOGLE_INTEGRATION_FILE, {});
      const token = req.headers['x-google-token'] || req.body?.googleToken || integration.accessToken;
      if (token) {
        await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events/${encodeURIComponent(booking.calendarEventId)}`, {
          method: 'PATCH',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            summary: `[CANCELLED] bylola: ${(booking.service || 'Appointment').split('(')[0].trim()} — ${booking.name || 'Client'}`
          })
        });
        console.log(`[Google Calendar] Marked event as cancelled on Google Calendar for ${booking.id}`);
      }
    } catch (err) {
      console.warn('Failed to mark event as cancelled on Google Calendar:', err.message);
    }
  } else if (status === 'confirmed' && !booking.calendarSynced) {
    // If reactivated or confirmed, auto-add to Google Calendar
    try {
      const integration = readJson(GOOGLE_INTEGRATION_FILE, {});
      const token = req.headers['x-google-token'] || req.body?.googleToken || integration.accessToken;
      if (token) {
        const calEvent = await createGoogleCalendarEvent(booking, token);
        if (calEvent && calEvent.id) {
          booking.calendarSynced = true;
          booking.calendarEventId = calEvent.id;
          booking.calendarEventUrl = calEvent.htmlLink;
          console.log(`[Google Calendar] Automatically created event for reactivated booking ${booking.id}`);
        }
      }
    } catch (err) {
      console.warn('Failed to auto-add reactivated booking to Google Calendar:', err.message);
    }
  }

  writeJson(BOOKINGS_FILE, bookings);
  res.json({ message: 'Booking updated', booking });
});

// 10. Delete Booking (Admin only)
app.delete('/api/bookings/:id', requireAdmin, async (req, res) => {
  const { id } = req.params;
  const bookings = readJson(BOOKINGS_FILE, []);
  const booking = bookings.find(b => b.id === id);

  if (!booking) {
    return res.status(404).json({ error: 'Booking not found' });
  }

  // Remove from Google Calendar if event exists
  if (booking.calendarEventId) {
    try {
      const explicitToken = req.headers['x-google-token'] || req.body?.googleToken;
      const integration = readJson(GOOGLE_INTEGRATION_FILE, {});
      const token = explicitToken || integration.accessToken;
      if (token) {
        await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events/${encodeURIComponent(booking.calendarEventId)}`, {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${token}` }
        });
        console.log(`[Google Calendar] Deleted calendar event ${booking.calendarEventId}`);
      }
    } catch (err) {
      console.warn('Failed to delete Google Calendar event:', err.message);
    }
  }

  const filtered = bookings.filter(b => b.id !== id);
  writeJson(BOOKINGS_FILE, filtered);
  res.json({ message: 'Booking removed' });
});

// ---------------- GOOGLE WORKSPACE ADMIN & STATUS ENDPOINTS ---------------- //

// Google Workspace Configuration
app.get('/api/google-workspace/config', (req, res) => {
  const fbConfig = readJson(FIREBASE_CONFIG_FILE, {});
  res.json({
    configured: true,
    firebaseConfig: fbConfig,
    scopes: SCOPES,
    ownerEmail: getAuthorizedOwnerEmail()
  });
});

// Google Workspace Status
app.get('/api/google-workspace/status', (req, res) => {
  const integration = readJson(GOOGLE_INTEGRATION_FILE, {});
  const hasToken = !!integration.accessToken;
  const isExpired = integration.expiresAt ? Date.now() > integration.expiresAt : false;

  res.json({
    connected: hasToken,
    active: hasToken && !isExpired,
    email: integration.email || getAuthorizedOwnerEmail(),
    name: integration.name || 'Lola',
    scopes: SCOPES,
    savedAt: integration.savedAt || null,
    expiresAt: integration.expiresAt || null,
    lastActivity: integration.lastActivity || null
  });
});

// Save Google Workspace OAuth Token (from Firebase Auth / GSI Sign-In)
app.post('/api/admin/save-google-token', async (req, res) => {
  const { accessToken, email, name, expiresAt } = req.body || {};
  if (!accessToken) {
    return res.status(400).json({ error: 'Missing accessToken' });
  }

  const normalizedEmail = (email || getAuthorizedOwnerEmail()).trim().toLowerCase();
  if (!isAuthorizedGoogleAccount(normalizedEmail)) {
    return res.status(403).json({ error: 'Unauthorized Google account. Only Lola\'s registered account is allowed.' });
  }

  const integrationData = {
    accessToken,
    email: normalizedEmail,
    name: name || 'Lola',
    expiresAt: expiresAt || (Date.now() + 3600 * 1000),
    savedAt: new Date().toISOString(),
    scopes: SCOPES
  };

  writeJson(GOOGLE_INTEGRATION_FILE, integrationData);
  console.log('[Google Workspace] Saved active token for', normalizedEmail);

  res.json({
    message: 'Google Workspace access token saved successfully',
    email: normalizedEmail,
    scopes: SCOPES
  });
});

// Test Google Workspace Integration (Sends a test email to admin & creates a test calendar event)
app.post('/api/admin/test-google', requireAdmin, async (req, res) => {
  const explicitToken = req.headers['x-google-token'] || req.body?.googleToken;
  const integration = readJson(GOOGLE_INTEGRATION_FILE, {});
  const token = explicitToken || integration.accessToken;

  if (!token) {
    return res.status(400).json({
      error: 'No active Google Workspace token available. Please sign in with Google in the portal.'
    });
  }

  const ownerEmail = getAuthorizedOwnerEmail();
  const testBooking = {
    id: 'test-' + Date.now().toString(36),
    service: 'Test Manicure Verification',
    date: new Date().toISOString().split('T')[0],
    time: '12:00',
    name: 'Test Reservation',
    contact: ownerEmail,
    notes: 'Testing Gmail API notifications and Google Calendar event sync.',
    status: 'test'
  };

  const results = {};

  // Test Calendar
  try {
    const calRes = await createGoogleCalendarEvent(testBooking, token);
    results.calendar = { success: true, eventId: calRes.id, htmlLink: calRes.htmlLink };
  } catch (err) {
    results.calendar = { success: false, error: err.message };
  }

  // Test Gmail
  try {
    const mailRes = await sendGmailEmail({
      to: ownerEmail,
      from: ownerEmail,
      subject: '✅ Google Workspace Integration Verified — bylola Studio',
      bodyHtml: `<div style="font-family:sans-serif;padding:24px;background:#f9f6f0;border-radius:6px;"><h2 style="color:#1a1715;">bylola Studio &middot; Google Integration Active</h2><p>This automated test confirms that both <strong>Gmail API</strong> and <strong>Google Calendar API</strong> are connected and communicating properly with your studio portal.</p><p style="color:#27ae60;font-weight:600;">&#10003; Client &amp; Admin email notifications are operational.<br>&#10003; Google Calendar event creation is operational.</p></div>`,
      bodyText: 'bylola Studio: Google Workspace Integration verified. Gmail and Google Calendar are active.',
      token
    });
    results.email = { success: true, messageId: mailRes.id };
  } catch (err) {
    results.email = { success: false, error: err.message };
  }

  res.json({
    message: 'Google Workspace test execution complete',
    results
  });
});

// Serve static assets from root directory
app.use(express.static(__dirname));

// Serve Admin Portal
app.get(['/admin', '/admin.html'], (req, res) => {
  res.sendFile(path.join(__dirname, 'admin.html'));
});

// Serve gallery page
app.get(['/gallery', '/gallery.html'], (req, res) => {
  res.sendFile(path.join(__dirname, 'gallery.html'));
});

// Serve index.html for all other page requests
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, HOST, () => {
  console.log(`bylola server running on http://${HOST}:${PORT}`);
  // Automatically sync any pending bookings to Google Calendar in background on boot
  setTimeout(() => {
    autoSyncUnsyncedBookings().catch(e => console.warn('[Boot Auto-Sync]', e.message));
  }, 1000);
});
